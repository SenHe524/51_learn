#ifndef _KEY_H_
#define _KEY_H_

unsigned char Key();

#endif