#ifndef _MATRIX_NUM_H_
#define _MATRIX_NUM_H_

unsigned char Matrix_Num();
unsigned char Matrix_State();
void Matrix_Loop();


#endif