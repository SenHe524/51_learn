#ifndef _AT24C02_H_
#define _AT24C02_H_

void AT24C02_WriteByte(unsigned char WordAddress,Data);
unsigned char AT24C02_ReadByte(unsigned WordAddress);

#endif