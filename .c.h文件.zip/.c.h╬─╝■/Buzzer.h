#ifndef _BUZZER_H_
#define _BUZZER_H_

void Buzzer_Time(unsigned int ms);


#endif