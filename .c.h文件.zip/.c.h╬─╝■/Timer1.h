#ifndef _TIMER1_H_
#define _TIMER1_H_

void Timer1_Init();

#endif