#ifndef _NIXIE_H_
#define _NIXIE_H_

void Nixie(unsigned char Location,Number);
void Nixie_Loop();
void Nixie_Scan(unsigned char Location,Number);

#endif