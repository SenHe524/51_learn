#ifndef _DS18B02_H_
#define _DS18B02_H_

void DS18B20_ConvertTemp();
float DS18B20_Read_T();

#endif