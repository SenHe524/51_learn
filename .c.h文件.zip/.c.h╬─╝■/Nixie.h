#ifndef _NIXIE_H_
#define _NIXIE_H_

void Nixie(unsigned char Location,Number);

#endif