#ifndef _KEY_TIMER_H_
#define _KEY_TIMER_H_

unsigned char Key();			//55��ʦ��ʿ���
unsigned char Key_GetState();
void Key_Loop();

#endif