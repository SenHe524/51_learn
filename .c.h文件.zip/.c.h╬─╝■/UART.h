#ifndef _UART_H_
#define _UART_H_

void UART_Init();
void UART_SendByte(unsigned char Data);
unsigned char UART_ReceiveByte();

#endif