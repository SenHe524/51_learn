#include <REGX52.H>
#include ".H"

unsigned char ;

void main()
{

	while(1)
	{
		
	}
}