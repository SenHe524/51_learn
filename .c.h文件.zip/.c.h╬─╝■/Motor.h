#ifndef _MOTOR_H_
#define _MOTOR_H_

void Motor_Init();
void Motor_SetSpeed(unsigned char Speed);

#endif