#ifndef _TIMER0_H_
#define _TIMER0_H_

void Timer0_Init();

#endif