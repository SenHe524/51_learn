#ifndef _DELAY_H_
#define _DELAY_H_

void Delayms(unsigned int ms);

#endif