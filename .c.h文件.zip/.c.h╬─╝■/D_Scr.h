#ifndef _DZP_H_
#define _DZP_H_

void D_Scr_Byte(unsigned int j);


#endif